﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SentMails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] == null)
        {
            Response.Redirect("Sigin.aspx");
        }
        if (!Page.IsPostBack)
        {
            DataSet ds = new DataSet();
            string connectionString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            try
            {
                SqlConnection connection = new SqlConnection(connectionString);
                SqlCommand command = new SqlCommand("get_SentMails", connection);
                command.CommandType = CommandType.StoredProcedure;
                connection.Open();
                command.Parameters.AddWithValue("@mailid", Convert.ToString(Session["EmailID"]));
                DataTable table = new DataTable();
                table.Load(command.ExecuteReader());
                ds.Tables.Add(table);
                connection.Close();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    dataGrid1.DataSource = ds;
                    dataGrid1.DataBind();
                    dataGrid1.Visible = true;
                    Fail.Visible = false;
                }
                else
                {
                    dataGrid1.Visible = false;
                    Fail.Visible = true;
                }

            }
            catch (Exception exs)
            { }
        }
    }

    protected void dataGrid1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        Session["MailTransID"] = e.CommandArgument;
        Response.Redirect("OpenMail.aspx");
    }
}