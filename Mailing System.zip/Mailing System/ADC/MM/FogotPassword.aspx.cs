﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FogotPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Verify_Click(object sender, EventArgs e)
    {
        DataSet ds;
        string connectionString = ConfigurationManager.ConnectionStrings["connString"].ToString();
        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter da = new SqlDataAdapter("select emailid, password from tbl_UserData where emailid='" + EmailID.Text + "' and SecurityAnswer='" + SecAnw.Text + "'", conn))
                {
                    da.SelectCommand.CommandType = CommandType.Text;
                    ds = new DataSet();
                    da.Fill(ds);
                }
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["EmailID"] = ds.Tables[0].Rows[0]["emailid"].ToString();
                Session["Password"]= ds.Tables[0].Rows[0]["password"].ToString();
                LoginFail.Visible = false;
                Response.Redirect("ChangePassword.aspx");
            }
            else
            {
                LoginFail.Visible = true;
            }

        }
        catch (Exception exs)
        { }
    }
}