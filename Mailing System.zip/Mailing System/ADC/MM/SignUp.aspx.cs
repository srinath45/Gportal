﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class SignUp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmailID"] != null)
        {
            Response.Redirect("Dashboard.aspx");
        }
    }

    protected void btn_SignUp_Click(object sender, EventArgs e)
    {
        try
        {
            string connectionString = ConfigurationManager.ConnectionStrings["connString"].ToString();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand da = new SqlCommand("insert into tbl_UserData values ('" + EmailID.Text+"','"+password.Text+"','"+FName.Text+"','"+LName.Text+"','"+ddl_Sex.SelectedValue+"','"+MobileNumber.Text+"','"+RMailID.Text+"','"+DateTime.Now+"','"+SecQues.Text+"','"+SecANs.Text+"')", conn))
                {
                    da.CommandType = CommandType.Text;
                    conn.Open();
                    da.ExecuteNonQuery();
                    conn.Close();
                }
            }
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand da = new SqlCommand("insert into tbl_LoginHistory values ('" + EmailID.Text + "','" + DateTime.Now + "','121.12.122.122')", conn))
                {
                    da.CommandType = CommandType.Text;
                    conn.Open();
                    da.ExecuteNonQuery();
                    conn.Close();
                }
            }
            Session["EmailID"] = EmailID.Text;
            Response.Redirect("Dashboard.aspx");
        }
        catch (Exception ex)
        { }
    }
}